import io

MINIMUM_VOTES = 15000
films = io.open('Z:\Desktop\PIC16_Final_Project\\films.txt', mode = 'r', encoding = 'latin-1').readlines()
ratings = io.open('Z:\Desktop\PIC16_Final_Project\\ratings.tsv', mode = 'r', encoding = 'latin-1').readlines()
tempDict = {}
for line in ratings[1:]:
    L = line[:-1].split('\t')
    if int(L[2]) >= MINIMUM_VOTES:
        tempDict[L[0]] = L[1]

film_ratings = {}
for film in films:
    if film[:-1] in tempDict:
        film_ratings[film[:-1]] = tempDict[film[:-1]]

filmRatings = io.open('C:\Users\uahmed98\.spyder\\film_ratings.py', mode = 'w', encoding = 'latin-1')
filmRatings.write(unicode('film_ratings = ' + str(film_ratings)))
filmRatings.close()