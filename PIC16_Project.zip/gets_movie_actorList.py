import io
from film_ratings import film_ratings
principals = io.open('Z:\Desktop\PIC16_Final_Project\\principals.tsv', mode = 'r', encoding = 'latin-1').readlines()
movie_actorList = {}
for film in film_ratings.keys():
    movie_actorList[film] = []
for i in range(1, len(principals)):
    L = principals[i][:-1].split('\t')
    if L[0] in movie_actorList and 'act' in L[3]:
        movie_actorList[L[0]].append(L[2])
        
movieActors = io.open('C:\Users\uahmed98\.spyder\\movie_actorList.py', mode = 'w', encoding = 'latin-1')
movieActors.write(unicode('movie_actorList = ' + str(movie_actorList)))
movieActors.close()