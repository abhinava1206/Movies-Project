from movie_actorList import movie_actorList
from film_ratings import film_ratings
from scipy.stats import linregress
import numpy as np
import partition as p
from SortedActors import sd
import matplotlib.pyplot as plt

numTopFiveHundred = []
ratings = []
for movie in movie_actorList:
    ratings.append(float(film_ratings[movie]))
    actors = movie_actorList[movie]
    count = 0
    for actor in actors:
        for i in range(500):
            if actor in sd[i]:
                count += 1
    numTopFiveHundred.append(count)
            
plt.scatter(ratings, numTopFiveHundred)
plt.xlabel('Rating out of 10')
plt.ylabel('Number of top 500 actors involved')
print linregress(ratings, numTopFiveHundred)

# Trying to do movie portfolio

# Movie portfolio
# TOP 500
space = 50
end = 500
portfolio_range = range(0, end, space)
#print portfolio_range
movie_labels = []
movie_port = []
movieList = movie_actorList.keys()
# For each movie

for i in range(len(movieList)):
    if float(film_ratings[movieList[i]]) >= 7:
        movie_labels.append(1)
    else:
        movie_labels.append(0)
    
    # For different ranges in top 500 actors
    for index in portfolio_range:
        count = 0
        # For each actor in the movie
        for actor in movie_actorList[movieList[i]]:
            for j in range(space):
                # If that actor appears in that range
                if actor == sd[i:i+space][j][0]:
                    count += 1
        if index == 0:
            movie_port.append([])
        movie_port[i].append(count)

# Convert to arrays
port = np.asanyarray(movie_port)
labels = np.asanyarray(movie_labels)

m = np.arange(0.1,1.0,0.1)
predict = [p.partition(port, labels, i)*100 for i in m]

plt.figure(2)
plt.plot(m*100,predict)
plt.xlabel("Percentage of Training Samples")
plt.ylabel("Prediction Accuracy")