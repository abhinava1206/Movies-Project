import io
from movie_actorList import movie_actorList
names = io.open('Z:\Desktop\PIC16_Final_Project\\names.tsv', mode = 'r', encoding = 'latin-1').readlines()
tempDict = {}
for line in names[1:]:
    L = line[:-1].split('\t')
    tempDict[L[0]] = L[1]

nameID_names = {}
for item in movie_actorList.items():
    for id in item[1]:
        nameID_names[id] = tempDict[id]
nameDict = io.open('C:\Users\uahmed98\.spyder\\nameID_names.py', mode = 'w', encoding = 'latin-1')
nameDict.write(unicode('nameID_names = ' + str(nameID_names)))
nameDict.close()