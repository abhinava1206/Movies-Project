#actually create the graph and run pagerank

#clean the data using the other four files
import gets_movies_from_titles
import gets_ratings_dict
import gets_movie_actorList
import gets_nameID_name


from movie_actorList import movie_actorList
from film_ratings import film_ratings
from nameID_names import nameID_names
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import io

#we weigh the edges as follows: for every tuple of actors (a1, a2): 
#divide the sum of all movies they appear in together by the sum of 
#ratings of all movies a1 has appeared in. For (a2, a1), divide by the sum
#for a2
actor_sumRatings = {}
actorPair_sumRatings = {}
G = nx.DiGraph()

#fewer films in film_ratings means fewer iterations
for item in film_ratings.items():
    rating = float(item[1])
    actors = movie_actorList[item[0]]
    index = len(actors)
    for i in range(index - 1):
        #adjust actor_sumRatings[actors[i]]
        if actors[i] in actor_sumRatings:
            actor_sumRatings[actors[i]] += rating
        else:
            actor_sumRatings[actors[i]] = rating
            
        for j in range(i + 1, index):
            #adjust actor_sumRatings[actors[j]]
            if actors[j] in actor_sumRatings:
                actor_sumRatings[actors[j]] += rating
            else:
                actor_sumRatings[actors[j]] = rating
            
            #adjust actorPair_sumRatings
            #equal for both orderings
            key1 = ((actors[i]),(actors[j]))
            key2 = ((actors[j]),(actors[i]))
            if key1 in actorPair_sumRatings:
                actorPair_sumRatings[key1] += rating
                actorPair_sumRatings[key2] += rating
            else:
                actorPair_sumRatings[key1] = rating
                actorPair_sumRatings[key2] = rating

#add edges to graph G with weights described in earlier comment... 
for edge in actorPair_sumRatings.keys():
    G.add_edge(edge[0], edge[1], weight = actorPair_sumRatings[edge]/actor_sumRatings[edge[0]])
    
#...and run pagerank
pr = nx.pagerank(G)

#sort the items of the pagerank dict by their 1st elements 
#which are the pagerank numbers
sd = sorted(pr.items(), key = lambda x:x[1], reverse = True)

#select top 20 actors to represent in graph
L = []
node_size = [0]*20

#we want to arrange the nodes in a spiral
#as we move away from the origin, 
position = {}
for i in range(20):
    L.append(sd[i][0])
    theta = float(6 + i)*np.pi/4.0
    r = theta
    position[sd[i][0]] = (r*np.cos(theta), r*np.sin(theta))
    node_size[i] = 300 - 15*r

#only want the top 20 actors in graph
H = G.subgraph(L)

#want to put each name of the actor in new line
labels = {}
for k in H.nodes():
    name = nameID_names[k].split(' ')
    relevant = ''
    for i in range(len(name)):
        relevant += name[i] + '\n'
    labels[k] = relevant

#draw graph
plt.figure(num = 1, figsize = (10, 10))
nx.draw_networkx(H, pos = position, nodelist = L,  with_labels = True, labels = labels, node_color = 'cyan',
                 node_size = node_size, edge_color = 'grey', width = 0.5, font_size = 10, arrows = False )
plt.axis('off')
plt.show()

f = io.open('SortedActors.py', mode = 'w', encoding = 'latin-1')
f.write(unicode('sd = ' + str(sd)))
f.close()