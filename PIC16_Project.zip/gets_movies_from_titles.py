import io
titles = io.open('Z:\Desktop\PIC16_Final_Project\\titles.tsv', mode = 'r', encoding = 'latin-1').readlines()
films = io.open('Z:\Desktop\PIC16_Final_Project\\films.txt', mode = 'w', encoding = 'latin-1')
for title in titles:
    L = title[:-1].split('\t')
    if L[1] == 'movie':
        films.write(unicode(str(L[0]) + '\n'))
films.close()